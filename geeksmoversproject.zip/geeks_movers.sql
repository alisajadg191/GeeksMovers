/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 10.1.10-MariaDB : Database - geeks_movers
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`geeks_movers` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `geeks_movers`;

/*Table structure for table `bus` */

DROP TABLE IF EXISTS `bus`;

CREATE TABLE `bus` (
  `bus_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) DEFAULT NULL,
  `bus_regs` varchar(255) DEFAULT NULL,
  `seats` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bus_id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `bus_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `bus_class` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `bus` */

insert  into `bus`(`bus_id`,`class_id`,`bus_regs`,`seats`) values (1,1,'xyz-123','33'),(2,2,'abc-321','45'),(8,4,'ad','45'),(9,1,'asd123','35'),(10,12,'RUK-874','20');

/*Table structure for table `bus_class` */

DROP TABLE IF EXISTS `bus_class`;

CREATE TABLE `bus_class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `bus_class` */

insert  into `bus_class`(`class_id`,`description`) values (1,'Royal'),(2,'Economy'),(3,'free'),(4,'luxury'),(7,'Premium'),(9,'standard'),(10,'Sukker'),(11,'Silver'),(12,'rukk'),(13,'Executive');

/*Table structure for table `expense` */

DROP TABLE IF EXISTS `expense`;

CREATE TABLE `expense` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_amount` int(11) DEFAULT NULL,
  `expense_details` varchar(255) DEFAULT NULL,
  `expense_date` date DEFAULT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `expense` */

/*Table structure for table `fare` */

DROP TABLE IF EXISTS `fare`;

CREATE TABLE `fare` (
  `fare_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `fare_amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`fare_id`),
  KEY `route_id` (`route_id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `fare_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`),
  CONSTRAINT `fare_ibfk_3` FOREIGN KEY (`class_id`) REFERENCES `bus_class` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `fare` */

insert  into `fare`(`fare_id`,`class_id`,`route_id`,`fare_amount`) values (3,1,2,700),(4,12,6,1200),(5,1,6,700);

/*Table structure for table `location` */

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `location` */

insert  into `location`(`location_id`,`location_name`) values (1,'Umerkot'),(2,'Sukker'),(4,'Karachi'),(5,'GHK'),(6,'Hyderabad'),(7,'Kashmore');

/*Table structure for table `passanger` */

DROP TABLE IF EXISTS `passanger`;

CREATE TABLE `passanger` (
  `passanger_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_name` varchar(255) DEFAULT NULL,
  `p_contact` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`passanger_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

/*Data for the table `passanger` */

insert  into `passanger`(`passanger_id`,`p_name`,`p_contact`) values (1,'Nand','012304142'),(2,'Nand','012310132'),(3,'nand','012983'),(4,'Nand','02840140'),(5,'Nand','04820123'),(6,'Nand','1230182'),(7,'Nand Lal','01238234'),(8,'Nand Lal','123012'),(9,'Nand Lal','0123123343'),(10,'Nand Lal','0801984'),(11,'Nand Lal','01233445'),(12,'Amjad','0303123445'),(13,'Amjad','0303123445'),(14,'Nand','03438333944'),(15,'Nand','03438333944'),(16,'Nand','03438333944'),(17,'Bilal','03000000000'),(18,'Nand','03438333944');

/*Table structure for table `reservation` */

DROP TABLE IF EXISTS `reservation`;

CREATE TABLE `reservation` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `passanger_id` int(11) DEFAULT NULL,
  `fare_id` int(11) DEFAULT NULL,
  `no_of_seats` varchar(255) DEFAULT NULL,
  `reservation_date` timestamp NULL DEFAULT NULL,
  `departure_date` timestamp NULL DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `bus_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`r_id`),
  KEY `passanger_id` (`passanger_id`),
  KEY `fare_id` (`fare_id`),
  KEY `route_id` (`route_id`),
  KEY `bus_id` (`bus_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`passanger_id`) REFERENCES `passanger` (`passanger_id`),
  CONSTRAINT `reservation_ibfk_5` FOREIGN KEY (`fare_id`) REFERENCES `fare` (`fare_id`),
  CONSTRAINT `reservation_ibfk_6` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`),
  CONSTRAINT `reservation_ibfk_7` FOREIGN KEY (`bus_id`) REFERENCES `bus` (`bus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `reservation` */

insert  into `reservation`(`r_id`,`passanger_id`,`fare_id`,`no_of_seats`,`reservation_date`,`departure_date`,`route_id`,`bus_id`) values (7,15,3,'2','2019-04-05 18:30:44','2019-04-06 04:00:00',2,1),(8,16,4,'3','2019-04-05 18:54:43','2019-04-05 10:30:00',6,10),(9,18,3,'1','2019-04-17 20:27:00','2019-03-13 10:00:00',2,1);

/*Table structure for table `route` */

DROP TABLE IF EXISTS `route`;

CREATE TABLE `route` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`route_id`),
  KEY `from_id` (`from_id`),
  KEY `to_id` (`to_id`),
  CONSTRAINT `route_ibfk_1` FOREIGN KEY (`from_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `route_ibfk_2` FOREIGN KEY (`to_id`) REFERENCES `location` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `route` */

insert  into `route`(`route_id`,`from_id`,`to_id`) values (1,4,1),(2,1,4),(4,2,4),(5,2,1),(6,5,6),(7,7,6);

/*Table structure for table `route_bus` */

DROP TABLE IF EXISTS `route_bus`;

CREATE TABLE `route_bus` (
  `rb_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `timing` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rb_id`),
  KEY `bus_id` (`bus_id`),
  KEY `route_id` (`route_id`),
  CONSTRAINT `route_bus_ibfk_4` FOREIGN KEY (`bus_id`) REFERENCES `bus` (`bus_id`),
  CONSTRAINT `route_bus_ibfk_5` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `route_bus` */

insert  into `route_bus`(`rb_id`,`bus_id`,`route_id`,`timing`) values (1,2,1,'12 am - 5 pm'),(2,1,2,'4 am - 9 pm'),(3,10,6,'10:30 - 12:10'),(4,1,1,'10 am - 3 pm'),(5,1,7,'10:00 AM - 6:00 PM');

/*Table structure for table `route_stops` */

DROP TABLE IF EXISTS `route_stops`;

CREATE TABLE `route_stops` (
  `route_stop_id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) DEFAULT NULL,
  `stop_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`route_stop_id`),
  KEY `route_id` (`route_id`),
  KEY `location_id` (`stop_id`),
  CONSTRAINT `route_stops_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`),
  CONSTRAINT `route_stops_ibfk_2` FOREIGN KEY (`stop_id`) REFERENCES `location` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `route_stops` */

insert  into `route_stops`(`route_stop_id`,`route_id`,`stop_id`) values (1,1,2),(2,4,4),(5,1,2),(6,6,2),(7,6,6);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`name`,`password`) values (2,'Sajad','ali'),(5,'nand','khatri'),(6,'Sadaquat Ali Ruk','123'),(7,'nand','khatri');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
